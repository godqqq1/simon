class RTD:
    temperature = 0.0
    def __init__(self):
        self.temperature = 0
    def takeTemp(self):
        temperature = 0.0;
    def getTemp(self):
        return self.temperature
        