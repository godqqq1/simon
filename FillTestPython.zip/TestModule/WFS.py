class WFS:
    wf = 0.0;
    def __init__(self):
        self.wf = 0.0
    def takeWF(self):
        wf = 0.0;
    def getWF(self):
        return self.wf