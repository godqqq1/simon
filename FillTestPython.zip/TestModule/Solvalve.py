class Solvalve:
    status = False
    def __init__(self):
        self.status = False
    def Onvalve(self):
        self.status = True
    def Offvalve(self):
        self.status = False
        
        