class GPIO:
    def __init__(self):
        print("123")
    def output(self):
        print(234)