import Heater
import RTD
import WL
class STank:
    heater1 = Heater.Heater()
    heater2 = Heater.Heater()
    heater3 = Heater.Heater()
    heater4 = Heater.Heater()
    temperature = RTD.RTD()
    wlstop = WL.WL()
    wlsbottom = WL.WL()
    def __init__(self):
        return
    
        