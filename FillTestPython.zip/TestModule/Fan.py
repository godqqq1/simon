import GPIO
class Fan:
    status = False
    def __init__(self):
        self.status = False
    def OnFan(self):
        status = True
        GPIO.output(22,True)
    def OffFan(self):
        status = False
        GPIO.output(22,False)