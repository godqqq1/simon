import WL
class ETank:
    wlstop = WL.WL()
    wlsbottom = WL.WL()
    def __init__(self):
        return