import GPIO
class Heater:
    status = False
    def __init__(self):
        self.status = False
    def OnHeater(self):
        self.status = True
        GPIO.output(27,True)
    def OffHeater(self):
        self.status = False
        GPIO.output(27,False)
    