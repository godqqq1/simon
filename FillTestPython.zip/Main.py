import Damper, ETank, Fan, Fill, Heater, MOV, Outemhum, Pressure, Pump, RTD, Solvalve, STank, WFS, WL

outempmax = 0
outempmin = 0
outhummax = 0
outhummin = 0
tanktempmax = 0
tanktempmin = 0
pressmax = 0
pressmin = 0
wantwf = 0
wantpress = 0
stank = STank.STank()
etank = ETank.ETank()
fill = Fill.Fill()
solvalve = Solvalve.Solvalve()
espump = Pump.Pump("espump")
fepump1 = Pump.Pump("fepump1")
fepump2 = Pump.Pump("fepump2")
sfpump = Pump.Pump("sfpump")
mov = MOV.MOV()
wfs = WFS.WFS()

while(True):
    
#            // Button is on?
    print("Button is on?")
#            // * yes : {
#            // * Button off;
#            // * STank is full?
    if stank.wlstop.status == True:
        print("Stank is full")
#                if (stank.wlstop.status == true) {
        stank.heater1.OnHeater()
        stank.heater2.OnHeater()
        stank.heater3.OnHeater()
        stank.heater4.OnHeater()
#                // * yes : {
#                // * heater on;
#                stank.heater1.OnHeater();
#                stank.heater2.OnHeater();
#                stank.heater3.OnHeater();
#                stank.heater4.OnHeater();
        if(fill.outemhum1.getTemp() < outempmax and fill.outemhum1.getTemp() >= outempmin and fill.outemhum1.getHumi() < outhummax and fill.outemhum1.getHumi() >= outhummin):
            print("outemp hum is good")
#                // * Outemhum is good?
#                if (fill.outemhum1.getTemp() < outempmax && fill.outemhum1.getTemp() >= outempmin
#                        && fill.outemhum1.getHumi() < outhummax && fill.outemhum1.getHumi() >= outhummin) {
            if(stank.temperature.getTemp() > tanktempmin and stank.temperature.getTemp() <= tanktempmax):
                    
# #                    // * yes : {
# #                    // * STank temperature is good?
#                    if (stank.temperature.getTemp() > tanktempmin && stank.temperature.getTemp() <= tanktempmax) {
#                        // * yes : {
#                        // * heater off;
                stank.heater1.OffHeater()
                stank.heater2.OffHeater()
                stank.heater3.OffHeater()
                stank.heater4.OffHeater()
                fill.damper.setDamper(wantpress)
#                        stank.heater1.OffHeater();
#                        stank.heater2.OffHeater();
#                        stank.heater3.OffHeater();
#                        stank.heater4.OffHeater();
#                        // * Pressure is good?
                if (fill.pressure.getPressure() > pressmin and fill.pressure.getPressure() <= pressmin) :
#                        if (fill.pressure.getPressure() > pressmin && fill.pressure.getPressure() <= pressmin) {
#                            // * yes : {
#                            // * SFPump and FEPump1,2 on;
                    sfpump.OnPump()  
                    fepump1.OnPump() 
                    fepump2.OnPump() 
#                            sfpump.OnPump();
#                            fepump1.OnPump();
#                            fepump2.OnPump();
#                            // * MOV pid controll;
                    mov.setMOV(wantwf)
#                            mov.setMOV(wantwf);
#                            // * wfs is good?
                    if (wfs.getWF() >= (wantwf - 5) and wfs.getWF() < (wantwf + 5)):
#                            if (wfs.getWF() >= (wantwf - 5) && wfs.getWF() < (wantwf + 5)) {
#                                // * yes : {
                        while (stank.wlsbottom.getStatus() == True) :
                                #Data Logging;(RTD,Pressure,outemhum,wf,time)
                                
#                                // * while(wle is on){
#                                while (stank.wlsbottom.getStatus() == true) {
#                                    // * Data Logging;(RTD,Pressure,outemhum,wf,time)
                            sfpump.OffPump() 
                            fepump1.OffPump()
                            fepump2.OffPump()
#                                }
#                                sfpump.OffPump();
#                                fepump1.OffPump();
#                                fepump2.OffPump();
#                                // water change
                            while(etank.wlsbottom.getStatus() == False):
                                espump.OnPump()
                            espump.OffPump()
                            if(stank.wlstop.getStatus() != True):
                                while(stank.wlstop.getStatus() != True):
                                    solvalve.Onvalve()
                                solvalve.Offvalve()
#                                while(etank.wlsbottom.getStatus() == false){
#                                    espump.OnPump();    
#                                }
#                                espump.OffPump();
#                                if(stank.wlstop.getStatus() != true){
#                                    while(stank.wlstop.getStatus() != true){
#                                        solvalve.Onvalve();
#                                    }
#                                    solvalve.Offvalve();
#                                }
#
#                            } else {
                    else :
                        mov.setMOV(wantwf)
                else :
                    fill.damper.setDamper(wantpress)
            else :
                stank.heater1.OnHeater()
                stank.heater2.OnHeater()   
                stank.heater3.OnHeater()   
                stank.heater4.OnHeater()
        else :
            print('refill')
#                                // * no : {
#                                // * MOV pid controll;
#                                mov.setMOV(wantwf);
#                            }
#
#                        } else {
#
#                            // * no : {
#                            // * Damper pid controll;
#                            fill.damper.setDamper(wantpress);
#                        }
#
#                    } else {
#                        // * no : {
#                        // * heater on;
#                        stank.heater1.OnHeater();
#                        stank.heater2.OnHeater();
#                        stank.heater3.OnHeater();
#                        stank.heater4.OnHeater();
#                    }
#
#                } else {
#                    // * no : {
#                    // * wait;
#                    
#                }
    else :
        print('refill')
#            } else {
#
#                // * no : {
#                // * refill water;
#            }

