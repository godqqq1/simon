from tkinter import *
import threading
import time
import serial
from operator import eq
import RPi.GPIO as GPIO
try:
        ser = serial.Serial('/dev/ttyACM0',9600)
except:
        time.sleep(1)
try:
        ser2 = serial.Serial('/dev/ttyACM1',9600)
except:
        time.sleep(1)
try:
        ser3 = serial.Serial('/dev/ttyACM2',9600)
except:
        time.sleep(1)
        
root = Tk()
#root.attributes('-fullscreen',True)
GPIO.setmode(GPIO.BCM)
GPIO.setup(17,GPIO.OUT)
GPIO.setup(22,GPIO.OUT)
GPIO.setup(27,GPIO.OUT)
frame = Frame(root,width=300,height=300)
frame.pack()

#Fan--------------------------------------------------------------------------
btn1text = "Off"
def ok1():
    global btn1text
    if eq(btn1text,"On") :
        print("true")
        btn1text = "Off"
                 GPIO.output(22,False)
#        ser.writelines("  0122190  ") #1.0V
        btn1.config(text = btn1text)
    else :
        btn1text = "On"
                GPIO.output(22,True)
                #GPIO.output(27,True)
#        ser.writelines("  0131740  ")
        #ser.writelines("  0131  ")
        btn1.config(text = btn1text)
lbl1 = Label(frame,text="Fan",font=("Courier",15))
lbl1.grid(row=0,column=0)
btn1 = Button(frame,text=btn1text,command=ok1,font=("Courier",15))
btn1.grid(row=1,column=0)


#Pump-------------------------------------------------------------------------
btn2text = "Off"
def ok2():
    global btn2text
    if eq(btn2text,"On") :
        print("true")
        btn2text = "Off"
        GPIO.output(17,False)
        btn2.config(text = btn2text)
    else :
        btn2text = "On"
        GPIO.output(17,True)
        btn2.config(text = btn2text)
lbl2 = Label(frame,text="Pump",font=("Courier",15))
lbl2.grid(row=0,column=1)
btn2 = Button(frame,text=btn2text,command=ok2,font=("Courier",15))
btn2.grid(row=1,column=1)

#Heater-----------------------------------------------------------------------
btn3text = "Off"
def ok3():
    global btn3text
    if eq(btn3text,"On") :
        print("true")
        btn3text = "Off"
        GPIO.output(27,False)
        btn3.config(text = btn3text)
    else :
        btn3text = "On"
        GPIO.output(27,True)
        btn3.config(text = btn3text)
lbl3 = Label(frame,text="Heater",font=("Courier",15))
lbl3.grid(row=0,column=2)
btn3 = Button(frame,text=btn3text,command=ok3,font=("Courier",15))
btn3.grid(row=1,column=2)




#Valve-----------------------------------------------------------------------
#btn3text = "On"
def ok4():
    global btn4text
    if eq(btn4text,"On") :
        print("true")
        btn4text = "Off"
        btn4.config(text = btn4text)
    else :
        btn4text = "On"
        btn4.config(text = btn4text)
scal4 = Entry(frame,width=5)#Scale(frame,tickinterval=1,length = 200,from_=0,to=9,showvalue=YES,orient='horizontal')
scal4.grid(row=1,column=3)
lbl4 = Label(frame,text="Valve",font=("Courier",15))
lbl4.grid(row=0,column=3)
btn4 = Button(frame,text="Generate",command=ok4,font=("Courier",8))
btn4.grid(row=2,column=3)



#Damper-----------------------------------------------------------------------
#btn3text = "On"
def ok5():
    global btn5text
    if eq(btn5text,"On") :
        print("true")
        btn5text = "Off"
        btn5.config(text = btn5text)
    else :
        btn5text = "On"
        btn5.config(text = btn5text)
scal5 = Entry(frame,width=5)#Scale(frame,tickinterval=1,length = 200,from_=0,to=9,showvalue=YES,orient='horizontal')
scal5.grid(row=1,column=4)
lbl5 = Label(frame,text="Damper",font=("Courier",15))
lbl5.grid(row=0,column=4)
btn5 = Button(frame,text="Generate",command=ok5,font=("Courier",8))
btn5.grid(row=2,column=4)


#--------------------------------------------------------------------------
lbldummy1 = Label(frame,text="                        ")
lbldummy1.grid(row=0,column=5)
lbldummy2 = Label(frame,text="      Out DBT  : ",font=("Courier",13))
lbldummy2.grid(row=0,column=6)
lbldummy3 = Label(frame,text=" Out Humidity  : ",font=("Courier",13))
lbldummy3.grid(row=1,column=6)
lbldummy4 = Label(frame,text="  ",font=("Courier",13))
lbldummy4.grid(row=0,column=7)
lbldummy5 = Label(frame,text="  ",font=("Courier",13))
lbldummy5.grid(row=1,column=7)
lbldummy6 = Label(frame,text="   Water Flow  : ",font=("Courier",13))
lbldummy6.grid(row=2,column=6)
lbldummy7 = Label(frame,text="Front Pressure : ",font=("Courier",13))
lbldummy7.grid(row=3,column=6)
lbldummy8 = Label(frame,text="  ",font=("Courier",13))
lbldummy8.grid(row=2,column=7)
lbldummy9 = Label(frame,text="  ",font=("Courier",13))
lbldummy9.grid(row=3,column=7)
lbldummy10 = Label(frame,text="Back Pressure  : ",font=("Courier",13))
lbldummy10.grid(row=4,column=6)
lbldummy11 = Label(frame,text="     Fill 1-1  : ",font=("Courier",13))
lbldummy11.grid(row=5,column=6)
lbldummy12 = Label(frame,text="  ",font=("Courier",13))
lbldummy12.grid(row=4,column=7)
lbldummy13 = Label(frame,text="  ",font=("Courier",13))
lbldummy13.grid(row=5,column=7)
lbldummy14 = Label(frame,text="     Fill 1-2  : ",font=("Courier",13))
lbldummy14.grid(row=6,column=6)
lbldummy15 = Label(frame,text="     Fill 1-3  : ",font=("Courier",13))
lbldummy15.grid(row=7,column=6)
lbldummy16 = Label(frame,text="  ",font=("Courier",13))
lbldummy16.grid(row=6,column=7)
lbldummy17 = Label(frame,text="  ",font=("Courier",13))
lbldummy17.grid(row=7,column=7)

lbldummy18 = Label(frame,text="     Fill 2-1  : ",font=("Courier",13))
lbldummy18.grid(row=8,column=6)
lbldummy19 = Label(frame,text="     Fill 2-2  : ",font=("Courier",13))
lbldummy19.grid(row=9,column=6)
lbldummy20 = Label(frame,text="  ",font=("Courier",13))
lbldummy20.grid(row=8,column=7)
lbldummy21 = Label(frame,text="  ",font=("Courier",13))
lbldummy21.grid(row=9,column=7)
lbldummy22 = Label(frame,text="     Fill 2-3  : ",font=("Courier",13))
lbldummy22.grid(row=10,column=6)
lbldummy23 = Label(frame,text="     Fill 3-1  : ",font=("Courier",13))
lbldummy23.grid(row=11,column=6)
lbldummy24 = Label(frame,text="  ",font=("Courier",13))
lbldummy24.grid(row=10,column=7)
lbldummy25 = Label(frame,text="  ",font=("Courier",13))
lbldummy25.grid(row=11,column=7)

lbldummy26 = Label(frame,text="     Fill 3-2  : ",font=("Courier",13))
lbldummy26.grid(row=12,column=6)
lbldummy27 = Label(frame,text="     Fill 3-3  : ",font=("Courier",13))
lbldummy27.grid(row=13,column=6)
lbldummy28 = Label(frame,text="  ",font=("Courier",13))
lbldummy28.grid(row=12,column=7)
lbldummy29 = Label(frame,text="  ",font=("Courier",13))
lbldummy29.grid(row=13,column=7)

class ThreadClass(threading.Thread):
        def run(self):
                while(1):
                        try:
                                now = ser.readline()
                                print(now)
                                if eq(now[:4],'1-1:'):
                                        lbldummy13.config(text=now[4:9])
                                elif eq(now[:4],'1-2:'):
                                        lbldummy16.config(text=now[4:9])
                                elif eq(now[:4],'1-3:'):
                                        lbldummy17.config(text=now[4:9])
                                elif eq(now[:4],'1-4:'):
                                        lbldummy20.config(text=now[4:9])
                                elif eq(now[:4],'2-1:'):
                                        lbldummy21.config(text=now[4:9])
                                elif eq(now[:8],'outtemp:'):
                                        lbldummy4.config(text=now[8:])
                                elif eq(now[:7],'outhum:'):
                                        lbldummy5.config(text=now[7:])
                                elif eq(now[:7],'chaap1:'):
                                        lbldummy9.config(text=now[7:])
                                elif eq(now[:7],'chaap2:'):
                                        lbldummy12.config(text=now[7:])
                                elif eq(now[:3],'WL:'):
                                        lbldummy8.config(text=now[3:])
                                
                        except:
                                time.sleep(1)
                        try:
                                now = ser2.readline()
                                print(now)
                                if eq(now[:4],'1-1:'):
                                        lbldummy13.config(text=now[4:9])
                                elif eq(now[:4],'1-2:'):
                                        lbldummy16.config(text=now[4:9])
                                elif eq(now[:4],'1-3:'):
                                        lbldummy17.config(text=now[4:9])
                                elif eq(now[:4],'1-4:'):
                                        lbldummy20.config(text=now[4:9])
                                elif eq(now[:4],'2-1:'):
                                        lbldummy21.config(text=now[4:9])
                                elif eq(now[:8],'outtemp:'):
                                        lbldummy4.config(text=now[8:])
                                elif eq(now[:7],'outhum:'):
                                        lbldummy5.config(text=now[7:])
                                elif eq(now[:7],'chaap1:'):
                                        lbldummy9.config(text=now[7:])
                                elif eq(now[:7],'chaap2:'):
                                        lbldummy12.config(text=now[7:])
                                elif eq(now[:3],'WL:'):
                                        lbldummy8.config(text=now[3:])
                        except:
                                time.sleep(1)
                        try:
                                now = ser3.readline()
                                print(now)
                                if eq(now[:4],'1-1:'):
                                        lbldummy13.config(text=now[4:9])
                                elif eq(now[:4],'1-2:'):
                                        lbldummy16.config(text=now[4:9])
                                elif eq(now[:4],'1-3:'):
                                        lbldummy17.config(text=now[4:9])
                                elif eq(now[:4],'1-4:'):
                                        lbldummy20.config(text=now[4:9])
                                elif eq(now[:4],'2-1:'):
                                        lbldummy21.config(text=now[4:9])
                                elif eq(now[:8],'outtemp:'):
                                        lbldummy4.config(text=now[8:])
                                elif eq(now[:7],'outhum:'):
                                        lbldummy5.config(text=now[7:])
                                elif eq(now[:7],'chaap1:'):
                                        lbldummy9.config(text=now[7:])
                                elif eq(now[:7],'chaap2:'):
                                        lbldummy12.config(text=now[7:])
                                elif eq(now[:3],'WL:'):
                                        lbldummy8.config(text=now[3:])
                                
                        except:
                                time.sleep(1)

class ThreadClass2(threading.Thread):
        def run(self):
                while(1):
                        try:
                                ser.writelines("valve:2055")
                                ser.writelines("damper:2055")
                        except:
                                time.sleep(1)
                        try:
                                ser2.writelines("valve:2055")
                                ser2.writelines("damper:2055")
                        except:
                                time.sleep(1)
                        try:
                                ser3.writelines("valve:2055")
                                ser3.writelines("damper:2055")
                        except:
                                time.sleep(1)
                        time.sleep(500)
tt = ThreadClass()
tt.start()
tt2 = ThreadClass2()
tt2.start()



root.mainloop()
