class Outemhum:
    temperature = 0.0
    humidity = 0.0
    def __init__(self):
        self.temperature = 0.0
        self.humidity = 0.0
    def takeTemp(self):
        self.temperature = 0.0
    def takeHumi(self):
        self.humidity = 0.0;
    def getTemp(self):
        return self.temperature
    def getHumi(self):
        return self.humidity 