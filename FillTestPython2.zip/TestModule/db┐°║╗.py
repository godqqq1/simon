import pyodbc
conn = pyodbc.connect('DRIVER=FreeTDS;SERVER=d2.onkr.com;PORT=1433;DATABASE=kimcoctcom;UID=kimcoctcom;PWD=ruddlsrlrP;TDS_Version=4.2;')

cursor = conn.cursor()

sql_text= 'select * from UserList'

cursor.execute(sql_text)

result=cursor.fetchall()

for row in result:

       p=row[1]

       q=row[2]

       print p

       print q
