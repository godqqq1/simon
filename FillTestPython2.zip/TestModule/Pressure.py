class Pressure:
    press = 0.0;
    def __init__(self):
        self.press = 0.0
    def takePressure(self):
        self.press = 0.0
    def getPressure(self):
        return self.press;