class MOV:
    level = 0.0;
    def __init__(self):
        self.level = 0.0
    def setMOV(self,width):
        self.level = width
    def getMOV(self):
        return self.level
        