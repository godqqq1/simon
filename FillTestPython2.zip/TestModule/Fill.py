import RTD
import Outemhum
import Pressure
import Damper
class Fill:
    rtd1 = RTD.RTD()
    rtd2 = RTD.RTD()
    rtd3 = RTD.RTD()
    rtd4 = RTD.RTD()
    rtd5 = RTD.RTD()
    rtd6 = RTD.RTD()
    rtd7 = RTD.RTD()
    rtd8 = RTD.RTD()
    rtd9 = RTD.RTD()
    rtd10 = RTD.RTD()
    rtd11 = RTD.RTD()
    rtd12 = RTD.RTD()
    rtd13 = RTD.RTD()
    rtd14 = RTD.RTD()
    rtd15 = RTD.RTD()
    rtd16 = RTD.RTD()
    rtd17 = RTD.RTD()
    rtd18 = RTD.RTD()
    outemhum1 = Outemhum.Outemhum()
    outemhum2 = Outemhum.Outemhum()
    pressure = Pressure.Pressure()
    damper = Damper.Damper()
    def __init__(self):
        return
    