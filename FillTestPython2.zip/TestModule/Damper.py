class Damper:
    level = 0.0;
    def __init__(self):
        self.level = 0.0
    def setDamper(self,t):
        level = t
    def getDamper(self):
        return self.level
        