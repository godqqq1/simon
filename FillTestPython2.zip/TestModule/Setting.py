from tkinter import *
import Main
class MyApp(object):
    """"""
 
    #----------------------------------------------------------------------
    def __init__(self, parent):
        """Constructor"""
        self.root = parent
        self.root.title("Fill Test System")
        self.frame = Frame(parent)
        self.frame.pack()
        title = Label(self.frame, text="Fill Test System")  # title label
        title.grid(row=0, column=0, columnspan=3)  # merge cell
        
        dummy = Label(self.frame, text="               ")
        dummy.grid(row=1, column=1)
        
        outempminl = Label(self.frame, text="Out Temperature min")
        outempminl.grid(row=1, column=0)
        
        outempmine = Entry(self.frame)
        outempmine.grid(row=1, column=2)
        
        outempmaxl = Label(self.frame, text="Out Temperature max")
        outempmaxl.grid(row=2, column=0)
        
        outempmaxe = Entry(self.frame)
        outempmaxe.grid(row=2, column=2)
        
        outhumminl = Label(self.frame, text="Out Humidity min")
        outhumminl.grid(row=3, column=0)
        
        outhummine = Entry(self.frame)
        outhummine.grid(row=3, column=2)
        
        outhummaxl = Label(self.frame, text="Out Humidity max")
        outhummaxl.grid(row=4, column=0)
        
        outhummaxe = Entry(self.frame)
        outhummaxe.grid(row=4, column=2)
        
        tanktempminl = Label(self.frame, text="Tank Temperature min")
        tanktempminl.grid(row=5, column=0)
        
        tanktempmine = Entry(self.frame)
        tanktempmine.grid(row=5, column=2)
        
        tanktempmaxl = Label(self.frame, text="Tank Temperature max")
        tanktempmaxl.grid(row=6, column=0)
        
        tanktempmaxe = Entry(self.frame)
        tanktempmaxe.grid(row=6, column=2)
        
        pressminl = Label(self.frame, text="Air Speed min")
        pressminl.grid(row=7, column=0)
        
        pressmine = Entry(self.frame)
        pressmine.grid(row=7, column=2)
        
        pressmaxl = Label(self.frame, text="Air Speed max")
        pressmaxl.grid(row=8, column=0)
        
        pressmine = Entry(self.frame)
        pressmine.grid(row=8, column=2)
        
        
        wantwfl = Label(self.frame, text="Appropriate Water Flow")
        wantwfl.grid(row=9, column=0)
        
        wantwfe = Entry(self.frame)
        wantwfe.grid(row=9, column=2)
        
        wantpressl = Label(self.frame, text="Appropriate Air Speed")
        wantpressl.grid(row=10, column=0)
        
        wantpresse = Entry(self.frame)
        wantpresse.grid(row=10, column=2)
        
        start = Button(self.frame, text="Start",command=self.openFrame)
        start.grid(row=11, column=1)

    #----------------------------------------------------------------------
    def hide(self):
        """"""
        self.root.withdraw()
 
    #----------------------------------------------------------------------
    def openFrame(self):
        """"""
        self.hide()
        otherFrame = Toplevel()
        otherFrame.geometry("400x300")
        otherFrame.title("Fill Test System")
        main = Main()
        
 
    #----------------------------------------------------------------------
    def onCloseOtherFrame(self, otherFrame):
        """"""
        otherFrame.destroy()
        self.show()
 
    #----------------------------------------------------------------------
    def show(self):
        """"""
        self.root.update()
        self.root.deiconify()
 
 
#----------------------------------------------------------------------
if __name__ == "__main__":
    root = Tk()
    app = MyApp(root)
# Code to add widgets will go here...
    root.mainloop()
