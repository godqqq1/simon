import Damper, ETank, Fan, Fill, Heater, MOV, Outemhum, Pressure, Pump, RTD, Solvalve, STank, WFS, WL
import threading
import time
import serial
from operator import eq
import RPi.GPIO as GPIO
try:
        ser = serial.Serial('/dev/ttyACM0',9600)
except:
        time.sleep(1)
try:
        ser2 = serial.Serial('/dev/ttyACM1',9600)
except:
        time.sleep(1)
try:
        ser3 = serial.Serial('/dev/ttyACM2',9600)
except:
        time.sleep(1)

GPIO.setmode(GPIO.BCM)
GPIO.setup(17,GPIO.OUT)
GPIO.setup(22,GPIO.OUT)
GPIO.setup(27,GPIO.OUT)
outempmax = input("Enter out Temperature Maximum value.")
outempmin = input("Enter out Temperature Minimum value.")
outhummax = input("Enter out Humidity Maximum value.")
outhummin = input("Enter out Humidity Minimum value.")
tanktempmax = input("Enter Tank Temperature Maximum value.")
tanktempmin = input("Enter Tank Temperature Minimum value.")
pressmax = input("Enter Air Speed Maximum value.")
pressmin = input("Enter Air Speed Minimum value.")
wantwf = input("Enter Appropriate Water Flow value.")
wantpress = input("Enter Appropriate Air Speed value.")
stank = STank.STank()
etank = ETank.ETank()
fill = Fill.Fill()
solvalve = Solvalve.Solvalve()
espump = Pump.Pump("espump")
fepump1 = Pump.Pump("fepump1")
fepump2 = Pump.Pump("fepump2")
sfpump = Pump.Pump("sfpump")
mov = MOV.MOV()
wfs = WFS.WFS()
while(True):
    
#            // Button is on?
    print("Button is on?")
#            // * yes : {
#            // * Button off;
#            // * STank is full?
    if stank.wlstop.getStatus() == True:
        print("Stank is full")
#                if (stank.wlstop.status == true) {
        stank.heater1.OnHeater()
        stank.heater2.OnHeater()
        stank.heater3.OnHeater()
        stank.heater4.OnHeater()
#                // * yes : {
#                // * heater on;
#                stank.heater1.OnHeater();
#                stank.heater2.OnHeater();
#                stank.heater3.OnHeater();
#                stank.heater4.OnHeater();
        if(fill.outemhum1.getTemp() < outempmax and fill.outemhum1.getTemp() >= outempmin and fill.outemhum1.getHumi() < outhummax and fill.outemhum1.getHumi() >= outhummin):
            print("outemp hum is good")
#                // * Outemhum is good?
#                if (fill.outemhum1.getTemp() < outempmax && fill.outemhum1.getTemp() >= outempmin
#                        && fill.outemhum1.getHumi() < outhummax && fill.outemhum1.getHumi() >= outhummin) {
            if(stank.temperature.getTemp() > tanktempmin and stank.temperature.getTemp() <= tanktempmax):
                    
# #                    // * yes : {
# #                    // * STank temperature is good?
#                    if (stank.temperature.getTemp() > tanktempmin && stank.temperature.getTemp() <= tanktempmax) {
#                        // * yes : {
#                        // * heater off;
                stank.heater1.OffHeater()
                stank.heater2.OffHeater()
                stank.heater3.OffHeater()
                stank.heater4.OffHeater()
                fill.damper.setDamper(wantpress)
#                        stank.heater1.OffHeater();
#                        stank.heater2.OffHeater();
#                        stank.heater3.OffHeater();
#                        stank.heater4.OffHeater();
#                        // * Pressure is good?
                if (fill.pressure.getPressure() > pressmin and fill.pressure.getPressure() <= pressmin) :
#                        if (fill.pressure.getPressure() > pressmin && fill.pressure.getPressure() <= pressmin) {
#                            // * yes : {
#                            // * SFPump and FEPump1,2 on;
                    sfpump.OnPump()  
                    fepump1.OnPump() 
                    fepump2.OnPump() 
#                            sfpump.OnPump();
#                            fepump1.OnPump();
#                            fepump2.OnPump();
#                            // * MOV pid controll;
                    mov.setMOV(wantwf)
#                            mov.setMOV(wantwf);
#                            // * wfs is good?
                    if (wfs.getWF() >= (wantwf - 5) and wfs.getWF() < (wantwf + 5)):
#                            if (wfs.getWF() >= (wantwf - 5) && wfs.getWF() < (wantwf + 5)) {
#                                // * yes : {
                        while (stank.wlsbottom.getStatus() == True) :
                                #Data Logging;(RTD,Pressure,outemhum,wf,time)
                                
#                                // * while(wle is on){
#                                while (stank.wlsbottom.getStatus() == true) {
#                                    // * Data Logging;(RTD,Pressure,outemhum,wf,time)
                            sfpump.OffPump() 
                            fepump1.OffPump()
                            fepump2.OffPump()
#                                }
#                                sfpump.OffPump();
#                                fepump1.OffPump();
#                                fepump2.OffPump();
#                                // water change
                            while(etank.wlsbottom.getStatus() == False):
                                espump.OnPump()
                            espump.OffPump()
                            if(stank.wlstop.getStatus() != True):
                                while(stank.wlstop.getStatus() != True):
                                    solvalve.Onvalve()
                                solvalve.Offvalve()
#                                while(etank.wlsbottom.getStatus() == false){
#                                    espump.OnPump();    
#                                }
#                                espump.OffPump();
#                                if(stank.wlstop.getStatus() != true){
#                                    while(stank.wlstop.getStatus() != true){
#                                        solvalve.Onvalve();
#                                    }
#                                    solvalve.Offvalve();
#                                }
#
#                            } else {
                    else :
                        mov.setMOV(wantwf)
                else :
                    fill.damper.setDamper(wantpress)
            else :
                stank.heater1.OnHeater()
                stank.heater2.OnHeater()   
                stank.heater3.OnHeater()   
                stank.heater4.OnHeater()
        else :
            print('wait')
#                                // * no : {
#                                // * MOV pid controll;
#                                mov.setMOV(wantwf);
#                            }
#                        } else {
#
#                            // * no : {
#                            // * Damper pid controll;
#                            fill.damper.setDamper(wantpress);
#                        }
#
#                    } else {
#                        // * no : {
#                        // * heater on;
#                        stank.heater1.OnHeater();
#                        stank.heater2.OnHeater();
#                        stank.heater3.OnHeater();
#                        stank.heater4.OnHeater();
#                    }
#
#                } else {
#                    // * no : {
#                    // * wait;
#                    
#                }
    else :
        print('refill')
#            } else {
#
#                // * no : {
#                // * refill water;
#            }

#class ThreadClass(threading.Thread):
#        def run(self):
#                while(1):
#                        try:
#                                now = ser.readline()
#                                print(now)
#                                if eq(now[:4],'1-1:'):
#                                        lbldummy13.config(text=now[4:9])
#                                elif eq(now[:4],'1-2:'):
#                                        lbldummy16.config(text=now[4:9])
#                                elif eq(now[:4],'1-3:'):
#                                        lbldummy17.config(text=now[4:9])
#                                elif eq(now[:4],'1-4:'):
#                                        lbldummy20.config(text=now[4:9])
#                                elif eq(now[:4],'2-1:'):
#                                        lbldummy21.config(text=now[4:9])
#                                elif eq(now[:8],'outtemp:'):
#                                        lbldummy4.config(text=now[8:])
#                                elif eq(now[:7],'outhum:'):
#                                        lbldummy5.config(text=now[7:])
#                                elif eq(now[:7],'chaap1:'):
#                                        lbldummy9.config(text=now[7:])
#                                elif eq(now[:7],'chaap2:'):
#                                        lbldummy12.config(text=now[7:])
#                                elif eq(now[:3],'WL:'):
#                                        lbldummy8.config(text=now[3:])
#                                
#                        except:
#                                time.sleep(1)
#                        try:
#                                now = ser2.readline()
#                                print(now)
#                                if eq(now[:4],'1-1:'):
#                                        lbldummy13.config(text=now[4:9])
#                                elif eq(now[:4],'1-2:'):
#                                        lbldummy16.config(text=now[4:9])
#                                elif eq(now[:4],'1-3:'):
#                                        lbldummy17.config(text=now[4:9])
#                                elif eq(now[:4],'1-4:'):
#                                        lbldummy20.config(text=now[4:9])
#                                elif eq(now[:4],'2-1:'):
#                                        lbldummy21.config(text=now[4:9])
#                                elif eq(now[:8],'outtemp:'):
#                                        lbldummy4.config(text=now[8:])
#                                elif eq(now[:7],'outhum:'):
#                                        lbldummy5.config(text=now[7:])
#                                elif eq(now[:7],'chaap1:'):
#                                        lbldummy9.config(text=now[7:])
#                                elif eq(now[:7],'chaap2:'):
#                                        lbldummy12.config(text=now[7:])
#                                elif eq(now[:3],'WL:'):
#                                        lbldummy8.config(text=now[3:])
#                        except:
#                                time.sleep(1)
#                        try:
#                                now = ser3.readline()
#                                print(now)
#                                if eq(now[:4],'1-1:'):
#                                        lbldummy13.config(text=now[4:9])
#                                elif eq(now[:4],'1-2:'):
#                                        lbldummy16.config(text=now[4:9])
#                                elif eq(now[:4],'1-3:'):
#                                        lbldummy17.config(text=now[4:9])
#                                elif eq(now[:4],'1-4:'):
#                                        lbldummy20.config(text=now[4:9])
#                                elif eq(now[:4],'2-1:'):
#                                        lbldummy21.config(text=now[4:9])
#                                elif eq(now[:8],'outtemp:'):
#                                        lbldummy4.config(text=now[8:])
#                                elif eq(now[:7],'outhum:'):
#                                        lbldummy5.config(text=now[7:])
#                                elif eq(now[:7],'chaap1:'):
#                                        lbldummy9.config(text=now[7:])
#                                elif eq(now[:7],'chaap2:'):
#                                        lbldummy12.config(text=now[7:])
#                                elif eq(now[:3],'WL:'):
#                                        lbldummy8.config(text=now[3:])
#                                
#                        except:
#                                time.sleep(1)
#