import pyodbc
class DB:
    conn = pyodbc.connect('DRIVER=FreeTDS;SERVER=d2.onkr.com;PORT=1433;DATABASE=kimcoctcom;UID=kimcoctcom;PWD=ruddlsrlrP;TDS_Version=4.2;')
    cursor = conn.cursor()
    def __init__(self):
        self.conn = pyodbc.connect('DRIVER=FreeTDS;SERVER=d2.onkr.com;PORT=1433;DATABASE=kimcoctcom;UID=kimcoctcom;PWD=ruddlsrlrP;TDS_Version=4.2;')
        self.cursor = self.conn.cursor()
    def insertLOG(self,time,rtd1,rtd2,rtd3,rtd4,rtd5,rtd6,rtd7,rtd8,rtd9,rtd10,rtd11,rtd12,rtd13,rtd14,rtd15,rtd16,rtd17,rtd18,press1,press2,outemp1,outemp2,outhumi1,outhumi2,wf):
        self.cursor.execute("insert into filltestLOG values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", time,rtd1,rtd2,rtd3,rtd4,rtd5,rtd6,rtd7,rtd8,rtd9,rtd10,rtd11,rtd12,rtd13,rtd14,rtd15,rtd16,rtd17,rtd18,press1,press2,outemp1,outemp2,outhumi1,outhumi2,wf)    
        self.conn.commit()
