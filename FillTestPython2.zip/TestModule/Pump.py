import GPIO
class Pump:
    pumpname = ""
    status = False
    def __init__(self, width):
        self.pumpname = width
        self.status = False
    def OnPump(self):
        self.status = True
        GPIO.output(17,True)
    def OffPump(self):
        self.status = False
        GPIO.output(17,False)