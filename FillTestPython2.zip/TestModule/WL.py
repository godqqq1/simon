class WL:
    status = False
    def __init__(self):
        self.status = False
    def getStatus(self):
        return self.status