/*
* Project name:
    4-20mA-R click
* Copyright:
    (c) Mikroelektronika, 2013.
* Revision History:
    20130130:
      - initial release (DO);
* Description:
    This project is a simple demonstration of working with the 4-20mA-R click board.
    12-bit A/D Converter (MCP3201) with SPI Serial Interface.
    The example for receiving measured values from host using 4-20mA-T click.
    Temperature value and measured current are displayed via UART.
* Test configuration:
    MCU:             PIC18F45K22
                     http://ww1.microchip.com/downloads/en/DeviceDoc/41412F.pdf
    Dev.Board:       EasyPIC v7
                     http://www.mikroe.com/easypic/
    Oscillator:      HS-PLL 32.0000 MHz, 8.0000 MHz Crystal
    Ext. Modules:    v4-20mA R click board  - ac:4-20mA-R_click
                     http://www.mikroe.com/click/4-20ma-r/
    SW:              mikroC PRO for PIC
                     http://www.mikroe.com/mikroc/pic/
* NOTES:
    - Place 4-20mA click board at the mikroBUS socket 1 on the EasyPIC7 board.
    - Put power supply jumper (J5) on the EasyPIC7 board in 3.3V position.
    - Maximal SPI clock frequency for MCP3204 running at 3.3V is 1MHz.
    - Input analog value should be in the range of 0 - 3.3V.
*/

// 4-20mA-R click module connections
sbit CS_MCP3201_Dir  at TRISE0_bit;
sbit CS_MCP3201      at LATE0_bit;
sbit Enable_Dir      at TRISB0_bit;
sbit Enable          at LATB0_bit;
// end of 4-20mA-R click module connections

const unsigned short TEMP_RESOLUTION = 9;
// Get ADC values
unsigned int getADC() {                            // Returns 0..4095
  int i = 0, avrg = 0;
  char adc_h, adc_l;
  unsigned int adc_tmp, adc_s[18], adc_sum = 0;
  char min_i, max_i;
  unsigned int min = 0x0FFF, max = 0;
  
  for(i = 0; i < 18 ; i++ ){                       // Get 16+2(min and max) ADC values
    CS_MCP3201 = 0;
    adc_h = SPI1_Read(0x12) & 0x1F;                // Get upper 4 bits of ADC value
    adc_l = SPI1_Read(0x12);                       // Get upper 8 bits of ADC value
    CS_MCP3201 = 1;
    adc_s[i] = ( ( adc_h  << 8 ) | adc_l) >> 1;    // Add ADC value to checkup array
    adc_sum += adc_s[i];                           // Sum ADC values
  }
  for(i = 0; i < 18 ; i++ ){                       // Search the array for MIN value
    if(min > adc_s[i]){
      min = adc_s[i];
      min_i = i;
    }
  }
  for(i = 0; i < 18 ; i++ ){                       // Search the array for MAX value
    if(max < adc_s[i]){
      max = adc_s[i];
      max_i = i;
    }
  }
  adc_sum -= adc_s[min_i];                         // Remove the MIN value from sum
  adc_sum -= adc_s[max_i];                         // Remove the MAX value from sum
  adc_sum >>= 4;                                   // Shift bits 4 places - divide the sum by 16 (2 to the power of 4)
  adc_sum += (adc_sum / 100);                      // Final value correction ~1% (Shunt resistor tolerance )
  return adc_sum;                                  // Returns 12-bit ADC result
}

// Write measured values to UART
void processValue(unsigned int valueTemp) {
  float mA_val;
  float temperature;
  char txt[12];
  if ((valueTemp < 4095) && (valueTemp > 800)){    // ADC value should be in range 800-4095 (4-20mA)
    mA_val = valueTemp * 102.4 / 4096.0 / 4.99;    // Vref=2048 A=20 Vref/A = 102.4 ; 12bit=4096 ; Shunt R = 4R99
    temperature = mA_val * 2.5;                    // Take a look at table from 4-20mA-T example project
    if ((temperature - floor(temperature)) < 0.5){ // Rounding up to 1/2 of deg.
      temperature = floor(temperature) + 0.5;
    }
    else{
      temperature = floor(temperature) + 1.0;
    }
    sprintf(txt, "T=%4.1f �C", temperature);       // Format Temperature value for output
    UART1_Write_Text(txt);                         // Print Temperature value
    UART1_Write(9);                                // Add TAB
    sprintf(txt, "I=%5.2f mA", mA_val);            // Format Current value for output
    UART1_Write_Text(txt);                         // Print Current value
    UART1_Write(13);                               //
    UART1_Write(10);                               // Add New line   CR+LF
  }
  else{
    UART1_Write_Text("Error");                     // In case when ADC value is not in 800-4095 range
    UART1_Write(13);                               //
    UART1_Write(10);                               // Add New line   CR+LF
  }
}

void main() {
  unsigned int measurement;
  ANSELB = 0;                      // Configure AN pins as digital
  ANSELC = 0;                      // Configure AN pins as digital
  ANSELE = 0;                      // Configure AN pins as digital
  SLRCON = 0;                      // Configure all PORTS at the standard Slew Rate

  measurement = 0;                 // Initialize the measurement variable

  Enable_Dir = 0;                  // Congfigure ENABLE pin
  Enable     = 1;                  // ENABLE voltage generator

  CS_MCP3201 = 1;                  // Deselect MCP3204
  CS_MCP3201_Dir = 0;              // Set chip select pin to be output
  UART1_Init(9600);                // Initialize UART
  Delay_100ms();                   // Wait for UART module to stabilize
  UART1_Write_Text("4-20mA-R Initialized");// Check the UART communication with simple
  UART1_Write(13);                 //
  UART1_Write(10);                 // Add New line   CR+LF
  // Initialize SPI1 module at 500kHz, data sampled at the middle of interval
  SPI1_Init_Advanced(_SPI_MASTER_OSC_DIV64, _SPI_DATA_SAMPLE_MIDDLE, _SPI_CLK_IDLE_LOW, _SPI_HIGH_2_LOW);
  
  while (1) {
    measurement = getADC();       // Get ADC result
    ProcessValue(measurement);    // Display Temperature an Current values via UART
    Delay_ms(333);                // Wait
  }
}